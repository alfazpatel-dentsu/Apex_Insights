
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ActionItem, ActionSection, ActionStatus, ActionPriority, Client, KpiData } from '@/lib/types';
import { useEffect, useState, useMemo } from 'react';
import { useFirestore, useCollection } from '@/firebase';
import { saveActionItem } from '@/lib/firestore-actions';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const actionSchema = z.object({
  taskName: z.string().min(1, 'Task name is required'),
  description: z.string().optional(),
  assignedTo: z.string().min(1, 'Assignee is required'),
  section: z.enum(["CLIENT ENGAGEMENT", "SALES", "OPERATIONS", "AZTEC", "HR", "MANAGEMENT"]),
  clientId: z.string().optional(),
  clientName: z.string().optional(),
  comment: z.string().optional(),
  status: z.enum(["Pending", "In Progress", "Completed", "Blocked"]),
  priority: z.enum(["Low", "Medium", "High", "Critical"]),
  dueDate: z.string().optional(),
});

type ActionFormValues = z.infer<typeof actionSchema>;

interface AddActionItemDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  clientId?: string;
  clientName?: string;
  action?: ActionItem | null;
}

const sections: ActionSection[] = ["CLIENT ENGAGEMENT", "SALES", "OPERATIONS", "AZTEC", "HR", "MANAGEMENT"];
const statuses: ActionStatus[] = ["Pending", "In Progress", "Completed", "Blocked"];
const priorities: ActionPriority[] = ["Low", "Medium", "High", "Critical"];

export function AddActionItemDialog({ isOpen, onOpenChange, clientId, clientName, action }: AddActionItemDialogProps) {
  const firestore = useFirestore();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  const { data: explicitClients } = useCollection<Client>('clients');
  const { data: kpiRecords } = useCollection<KpiData>('kpis');

  // DISCOVERY RITUAL: Merge registered clients with ones found in KPI records
  const discoveredClients = useMemo(() => {
    const uniqueList: { uniqueId: string, name: string }[] = [];
    const seenIds = new Set<string>();
    
    if (explicitClients) {
      explicitClients.forEach(c => {
        if (c.uniqueId && !seenIds.has(c.uniqueId)) {
          uniqueList.push({ uniqueId: c.uniqueId, name: c.name });
          seenIds.add(c.uniqueId);
        }
      });
    }
    
    if (kpiRecords) {
      kpiRecords.forEach(k => {
        if (k.clientId && !seenIds.has(k.clientId)) {
          uniqueList.push({ uniqueId: k.clientId, name: k.clientName });
          seenIds.add(k.clientId);
        }
      });
    }
    return uniqueList.sort((a, b) => a.name.localeCompare(b.name));
  }, [explicitClients, kpiRecords]);

  const form = useForm<ActionFormValues>({
    resolver: zodResolver(actionSchema),
    defaultValues: {
      taskName: '',
      description: '',
      assignedTo: '',
      section: 'OPERATIONS',
      clientId: clientId || '',
      clientName: clientName || '',
      comment: '',
      status: 'Pending',
      priority: 'Medium',
      dueDate: '',
    }
  });

  useEffect(() => {
    if (isOpen) {
      if (action) {
        form.reset({
          taskName: action.taskName,
          description: action.description || '',
          assignedTo: action.assignedTo,
          section: action.section,
          clientId: action.clientId || '',
          clientName: action.clientName || '',
          comment: action.comment || '',
          status: action.status,
          priority: action.priority,
          dueDate: action.dueDate || '',
        });
      } else {
        form.reset({
          taskName: '',
          description: '',
          assignedTo: '',
          section: 'OPERATIONS',
          clientId: clientId || '',
          clientName: clientName || '',
          comment: '',
          status: 'Pending',
          priority: 'Medium',
          dueDate: '',
        });
      }
    }
  }, [isOpen, action, clientId, clientName, form]);

  const onSubmit = async (data: ActionFormValues) => {
    setIsSaving(true);
    try {
      // Find client name if clientId changed manually
      let finalClientName = data.clientName;
      if (data.clientId && !data.clientName) {
          const found = discoveredClients?.find(c => c.uniqueId === data.clientId);
          if (found) finalClientName = found.name;
      }

      await saveActionItem(firestore, { ...data, clientName: finalClientName }, action?.id);
      toast({ title: action ? "Task updated" : "Task created" });
      onOpenChange(false);
    } catch (e: any) {
      toast({ variant: 'destructive', title: "Save failed", description: e.message });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto rounded-[2.5rem] glass">
        <DialogHeader>
          <DialogTitle className="font-headline text-3xl font-black uppercase tracking-tighter">
            {action ? 'Update Action Item' : 'New Action Item'}
          </DialogTitle>
          <DialogDescription className="text-foreground/60 font-bold uppercase text-[10px] tracking-widest">
            Define deliverables and assign accountability for the WBR WoW cycle.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-8 rounded-[2rem] bg-foreground/[0.03] border border-foreground/5">
                <FormField control={form.control} name="taskName" render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Task Name</FormLabel>
                    <FormControl><Input className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-bold" placeholder="Define clear deliverable..." {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="assignedTo" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Assigned To</FormLabel>
                    <FormControl><Input className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-bold" placeholder="Identity of owner..." {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="section" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Section / Domain</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-black"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent className="rounded-xl glass border-none">
                        {sections.map(s => <SelectItem key={s} value={s} className="font-bold text-[10px]">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

                <FormField control={form.control} name="clientId" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Client Context (Optional)</FormLabel>
                    <Select 
                      onValueChange={(val) => {
                        const actualVal = val === "none" ? "" : val;
                        field.onChange(actualVal);
                        if (actualVal) {
                          const c = discoveredClients?.find(x => x.uniqueId === actualVal);
                          if (c) form.setValue('clientName', c.name);
                        } else {
                          form.setValue('clientName', '');
                        }
                      }} 
                      value={field.value || "none"}
                    >
                      <FormControl><SelectTrigger className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-bold"><SelectValue placeholder="No Client" /></SelectTrigger></FormControl>
                      <SelectContent className="rounded-xl glass border-none">
                        <SelectItem value="none" className="font-bold text-[10px]">GLOBAL / NO CLIENT</SelectItem>
                        {discoveredClients?.map(c => <SelectItem key={c.uniqueId} value={c.uniqueId} className="font-bold text-[10px]">{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

                <FormField control={form.control} name="dueDate" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Due Date</FormLabel>
                    <FormControl><Input type="date" className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-mono font-bold" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-black"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent className="rounded-xl glass border-none">
                        {statuses.map(s => <SelectItem key={s} value={s} className="font-bold text-[10px]">{s.toUpperCase()}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />

                <FormField control={form.control} name="priority" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60">Criticality</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="rounded-xl bg-background/50 border-none h-12 shadow-inner px-4 font-black"><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent className="rounded-xl glass border-none">
                        {priorities.map(p => <SelectItem key={p} value={p} className="font-bold text-[10px]">{p.toUpperCase()}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )} />
            </div>

            <div className="space-y-4">
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60 px-2">Task Details</FormLabel>
                  <FormControl><Textarea className="rounded-[2rem] bg-foreground/[0.03] border-none min-h-[100px] shadow-inner p-6 text-sm font-medium leading-relaxed resize-none" placeholder="Deep dive context..." {...field} /></FormControl>
                </FormItem>
              )} />

              <FormField control={form.control} name="comment" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[10px] font-black uppercase tracking-widest opacity-60 px-2">Comments / Intelligence</FormLabel>
                  <FormControl><Textarea className="rounded-[2rem] bg-foreground/[0.03] border-none min-h-[100px] shadow-inner p-6 text-sm font-medium leading-relaxed resize-none" placeholder="Latest update..." {...field} /></FormControl>
                </FormItem>
              )} />
            </div>

            <DialogFooter className="pt-6 border-t border-foreground/5">
                <Button type="button" variant="ghost" className="rounded-xl h-12 px-6 font-bold" onClick={() => onOpenChange(false)}>Cancel</Button>
                <Button type="submit" className="rounded-xl h-12 px-10 font-black shadow-xl shadow-primary/20 uppercase tracking-widest text-[10px]" disabled={isSaving}>
                  {isSaving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Save Task
                </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
